"""Tkinter graphical interface for Student Performance System."""
import tkinter as tk
from tkinter import ttk, messagebox, simpledialog, filedialog
import pandas as pd

from student import Student, UndergraduateStudent, PostgraduateStudent
from analysis import make_dataframe, summary, clean_missing_marks
from graphs import show_bar_chart, show_grade_pie, show_student_line, show_correlation_heatmap

SUBJECTS = ["Python", "DBMS", "Web Programming", "Mobile Computing"]


class StudentPerformanceApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Student Performance Management & Analysis System")
        self.root.geometry("1080x680")
        self.root.minsize(900, 580)
        self.students = []

        title = ttk.Label(
            root, text="STUDENT PERFORMANCE MANAGEMENT SYSTEM",
            font=("Arial", 17, "bold")
        )
        title.pack(pady=(14, 4))
        ttk.Label(
            root, text="Manage student records, calculate results, and visualize class performance"
        ).pack(pady=(0, 12))

        form = ttk.LabelFrame(root, text="Student Details", padding=12)
        form.pack(fill="x", padx=14, pady=6)

        self.roll_var = tk.StringVar()
        self.name_var = tk.StringVar()
        self.mark_vars = [tk.StringVar() for _ in SUBJECTS]

        ttk.Label(form, text="Roll Number").grid(row=0, column=0, sticky="w", padx=5, pady=5)
        ttk.Entry(form, textvariable=self.roll_var, width=18).grid(row=0, column=1, padx=5, pady=5)
        ttk.Label(form, text="Student Name").grid(row=0, column=2, sticky="w", padx=5, pady=5)
        ttk.Entry(form, textvariable=self.name_var, width=22).grid(row=0, column=3, padx=5, pady=5)

        for i, subject in enumerate(SUBJECTS):
            ttk.Label(form, text=f"{subject} (0-100)").grid(
                row=1, column=i * 2, sticky="w", padx=5, pady=5
            )
            ttk.Entry(form, textvariable=self.mark_vars[i], width=12).grid(
                row=1, column=i * 2 + 1, padx=5, pady=5
            )

        actions = ttk.Frame(root)
        actions.pack(fill="x", padx=14, pady=6)
        ttk.Button(actions, text="Add Student", command=self.add_student).pack(side="left", padx=3)
        ttk.Button(actions, text="Update Selected", command=self.update_student).pack(side="left", padx=3)
        ttk.Button(actions, text="Delete Selected", command=self.delete_student).pack(side="left", padx=3)
        ttk.Button(actions, text="Clear Form", command=self.clear_form).pack(side="left", padx=3)
        ttk.Button(actions, text="Search Roll No.", command=self.search_student).pack(side="left", padx=3)
        ttk.Button(actions, text="Class Statistics", command=self.show_statistics).pack(side="left", padx=3)

        table_frame = ttk.Frame(root)
        table_frame.pack(fill="both", expand=True, padx=14, pady=8)
        columns = ("roll", "name", *SUBJECTS, "total", "percentage", "grade")
        self.tree = ttk.Treeview(table_frame, columns=columns, show="headings", height=12)
        headings = {
            "roll": "Roll No.", "name": "Name", "Python": "Python",
            "DBMS": "DBMS", "Web Programming": "Web Programming",
            "Mobile Computing": "Mobile Computing", "total": "Total",
            "percentage": "Percentage", "grade": "Grade"
        }
        widths = {"roll": 75, "name": 130, "Python": 75, "DBMS": 75,
                  "Web Programming": 110, "Mobile Computing": 120,
                  "total": 75, "percentage": 95, "grade": 65}
        for col in columns:
            self.tree.heading(col, text=headings.get(col, col))
            self.tree.column(col, width=widths.get(col, 90), anchor="center")
        yscroll = ttk.Scrollbar(table_frame, orient="vertical", command=self.tree.yview)
        xscroll = ttk.Scrollbar(table_frame, orient="horizontal", command=self.tree.xview)
        self.tree.configure(yscrollcommand=yscroll.set, xscrollcommand=xscroll.set)
        self.tree.grid(row=0, column=0, sticky="nsew")
        yscroll.grid(row=0, column=1, sticky="ns")
        xscroll.grid(row=1, column=0, sticky="ew")
        table_frame.rowconfigure(0, weight=1)
        table_frame.columnconfigure(0, weight=1)
        self.tree.bind("<<TreeviewSelect>>", self.on_select)

        graph_frame = ttk.LabelFrame(root, text="Data Analysis & Graphs", padding=8)
        graph_frame.pack(fill="x", padx=14, pady=(0, 12))
        ttk.Button(graph_frame, text="Subject Bar Chart", command=lambda: self.run_graph(show_bar_chart)).pack(side="left", padx=4)
        ttk.Button(graph_frame, text="Grade Pie Chart", command=lambda: self.run_graph(show_grade_pie)).pack(side="left", padx=4)
        ttk.Button(graph_frame, text="Student Line Graph", command=lambda: self.run_graph(show_student_line)).pack(side="left", padx=4)
        ttk.Button(graph_frame, text="Correlation Heatmap", command=lambda: self.run_graph(show_correlation_heatmap)).pack(side="left", padx=4)
        ttk.Button(graph_frame, text="Export CSV", command=self.export_csv).pack(side="left", padx=4)
        ttk.Button(graph_frame, text="Import Demo Data", command=self.load_demo_data).pack(side="left", padx=4)

        self.status = tk.StringVar(value="Ready. Add a student to begin.")
        ttk.Label(root, textvariable=self.status, relief="sunken", anchor="w").pack(fill="x", side="bottom")

    def get_form_values(self):
        roll = self.roll_var.get().strip()
        name = self.name_var.get().strip()
        if not roll or not name:
            raise ValueError("Please enter both roll number and student name.")
        marks = []
        for subject, variable in zip(SUBJECTS, self.mark_vars):
            value = variable.get().strip()
            if value == "":
                marks.append(None)
                continue
            try:
                mark = float(value)
            except ValueError:
                raise ValueError(f"{subject} must be a number from 0 to 100.")
            if not 0 <= mark <= 100:
                raise ValueError(f"{subject} must be between 0 and 100.")
            marks.append(mark)
        if all(mark is None for mark in marks):
            raise ValueError("Enter at least one subject mark.")
        return roll, name, marks

    def add_student(self):
        try:
            roll, name, marks = self.get_form_values()
            if any(s.rollno == roll for s in self.students):
                messagebox.showerror("Duplicate Roll Number", "That roll number already exists.")
                return
            student = Student(roll, name, marks)
            self.students.append(student)
            self.refresh_table()
            self.clear_form()
            self.status.set(f"Added student {name}.")
        except ValueError as exc:
            messagebox.showerror("Input Error", str(exc))

    def selected_student(self):
        selection = self.tree.selection()
        if not selection:
            messagebox.showwarning("Select Student", "Select a student row first.")
            return None
        roll = self.tree.item(selection[0], "values")[0]
        return next((s for s in self.students if s.rollno == str(roll)), None)

    def update_student(self):
        student = self.selected_student()
        if student is None:
            return
        try:
            roll, name, marks = self.get_form_values()
            if roll != student.rollno and any(s.rollno == roll for s in self.students):
                raise ValueError("Another student already uses that roll number.")
            student.rollno, student.name, student.marks = roll, name, marks
            self.refresh_table()
            self.clear_form()
            self.status.set(f"Updated student {name}.")
        except ValueError as exc:
            messagebox.showerror("Input Error", str(exc))

    def delete_student(self):
        student = self.selected_student()
        if student is None:
            return
        if messagebox.askyesno("Confirm Delete", f"Delete {student.name}'s record?"):
            self.students.remove(student)
            self.refresh_table()
            self.clear_form()
            self.status.set("Student record deleted.")

    def search_student(self):
        roll = simpledialog.askstring("Search Student", "Enter roll number:")
        if roll is None:
            return
        student = next((s for s in self.students if s.rollno == roll.strip()), None)
        if student is None:
            messagebox.showinfo("Search Result", "No student found with that roll number.")
        else:
            self.fill_form(student)
            for item in self.tree.get_children():
                if str(self.tree.item(item, "values")[0]) == student.rollno:
                    self.tree.selection_set(item)
                    self.tree.see(item)
                    break
            messagebox.showinfo("Student Found", student.display_details())

    def on_select(self, _event=None):
        student = self.selected_student_silent()
        if student:
            self.fill_form(student)

    def selected_student_silent(self):
        selection = self.tree.selection()
        if not selection:
            return None
        roll = str(self.tree.item(selection[0], "values")[0])
        return next((s for s in self.students if s.rollno == roll), None)

    def fill_form(self, student):
        self.roll_var.set(student.rollno)
        self.name_var.set(student.name)
        for variable, mark in zip(self.mark_vars, student.marks):
            variable.set("" if mark is None else str(mark))

    def clear_form(self):
        self.roll_var.set("")
        self.name_var.set("")
        for variable in self.mark_vars:
            variable.set("")
        for item in self.tree.selection():
            self.tree.selection_remove(item)

    def refresh_table(self):
        for item in self.tree.get_children():
            self.tree.delete(item)
        for student in self.students:
            values = [student.rollno, student.name]
            values.extend("" if mark is None else f"{mark:g}" for mark in student.marks)
            values.extend([f"{student.total():.2f}", f"{student.percentage():.2f}%", student.grade()])
            self.tree.insert("", "end", values=values)
        self.status.set(f"Total students: {len(self.students)}")

    def current_dataframe(self):
        return make_dataframe(self.students, SUBJECTS)

    def show_statistics(self):
        if not self.students:
            messagebox.showinfo("Class Statistics", "Add students first.")
            return
        stats = summary(self.students)
        top = max(self.students, key=lambda s: s.percentage())
        bottom = min(self.students, key=lambda s: s.percentage())
        messagebox.showinfo(
            "Class Statistics",
            f"Students: {stats['count']}\n"
            f"Class average: {stats['average']:.2f}%\n"
            f"Highest: {top.name} ({top.percentage():.2f}%)\n"
            f"Lowest: {bottom.name} ({bottom.percentage():.2f}%)"
        )

    def run_graph(self, graph_function):
        if not self.students:
            messagebox.showinfo("No Data", "Add students or import demo data first.")
            return
        try:
            df = self.current_dataframe()
            if graph_function == show_bar_chart:
                graph_function(df, SUBJECTS)
            elif graph_function == show_student_line:
                graph_function(df, SUBJECTS)
            elif graph_function == show_correlation_heatmap:
                graph_function(df, SUBJECTS)
            else:
                graph_function(df)
        except Exception as exc:
            messagebox.showerror("Graph Error", str(exc))

    def export_csv(self):
        if not self.students:
            messagebox.showinfo("Export CSV", "There are no records to export.")
            return
        path = filedialog.asksaveasfilename(
            title="Save student data", defaultextension=".csv",
            filetypes=[("CSV files", "*.csv")]
        )
        if not path:
            return
        try:
            self.current_dataframe().to_csv(path, index=False)
            messagebox.showinfo("Export Complete", f"Student data saved to:\n{path}")
        except Exception as exc:
            messagebox.showerror("Export Error", str(exc))

    def load_demo_data(self):
        demo = [
            Student("101", "Anshi", [85, 90, 88, 92]),
            UndergraduateStudent("102", "Priya", [78, 82, 80, 76]),
            PostgraduateStudent("103", "Riya", [92, 95, 91, 94]),
            Student("104", "Neha", [66, 72, 69, 75]),
            Student("105", "Aman", [55, 61, 58, 64]),
        ]
        existing = {s.rollno for s in self.students}
        added = 0
        for student in demo:
            if student.rollno not in existing:
                self.students.append(student)
                added += 1
        self.refresh_table()
        self.status.set(f"Loaded {added} demo student(s). Demo data is illustrative.")
        messagebox.showinfo("Demo Data", f"Loaded {added} sample records. You can edit or delete them.")


def main():
    root = tk.Tk()
    StudentPerformanceApp(root)
    root.mainloop()


if __name__ == "__main__":
    main()
