"""NumPy and Pandas analysis helpers for the student project."""
import numpy as np
import pandas as pd


def make_dataframe(students, subjects):
    rows = []
    for student in students:
        row = {"Roll No": student.rollno, "Name": student.name}
        for index, subject in enumerate(subjects):
            mark = student.marks[index] if index < len(student.marks) else None
            row[subject] = mark
        row["Total"] = student.total()
        row["Percentage"] = student.percentage()
        row["Grade"] = student.grade()
        rows.append(row)
    return pd.DataFrame(rows)


def summary(students):
    percentages = np.array([s.percentage() for s in students], dtype=float)
    if len(percentages) == 0:
        return {
            "count": 0, "average": 0.0, "highest": None, "lowest": None
        }
    return {
        "count": int(len(percentages)),
        "average": float(np.mean(percentages)),
        "highest": float(np.max(percentages)),
        "lowest": float(np.min(percentages)),
    }


def clean_missing_marks(df, subjects):
    """Fill missing subject marks with that subject's median."""
    result = df.copy()
    for subject in subjects:
        if subject in result.columns:
            median = result[subject].median()
            result[subject] = result[subject].fillna(0 if pd.isna(median) else median)
    return result
