"""Run this file to start the project."""
from gui import main

if __name__ == "__main__":
    main()
