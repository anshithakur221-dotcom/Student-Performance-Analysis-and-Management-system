"""Matplotlib and Seaborn visualizations."""
import matplotlib.pyplot as plt
import seaborn as sns


def show_bar_chart(df, subjects):
    if df.empty:
        raise ValueError("Add at least one student before making graphs.")
    averages = df[subjects].mean(numeric_only=True)
    averages.plot(kind="bar")
    plt.title("Average Marks by Subject")
    plt.xlabel("Subject")
    plt.ylabel("Average Marks")
    plt.ylim(0, 100)
    plt.tight_layout()
    plt.show()


def show_grade_pie(df):
    if df.empty:
        raise ValueError("Add at least one student before making graphs.")
    counts = df["Grade"].value_counts()
    counts.plot(kind="pie", autopct="%1.1f%%", startangle=90)
    plt.title("Grade Distribution")
    plt.ylabel("")
    plt.tight_layout()
    plt.show()


def show_student_line(df, subjects):
    if df.empty:
        raise ValueError("Add at least one student before making graphs.")
    names = df["Name"].astype(str).tolist()
    for subject in subjects:
        plt.plot(names, df[subject], marker="o", label=subject)
    plt.title("Student Marks by Subject")
    plt.xlabel("Student")
    plt.ylabel("Marks")
    plt.ylim(0, 100)
    plt.legend()
    plt.xticks(rotation=25, ha="right")
    plt.tight_layout()
    plt.show()


def show_correlation_heatmap(df, subjects):
    if df.empty:
        raise ValueError("Add at least one student before making graphs.")
    numeric = df[subjects].apply(lambda col: col.fillna(col.median()))
    sns.heatmap(numeric.corr(), annot=True, vmin=-1, vmax=1, cmap="coolwarm")
    plt.title("Subject Marks Correlation")
    plt.tight_layout()
    plt.show()
