class Student:
    """Stores one student's information and calculates their result."""

    def __init__(self, rollno, name, marks):
        self.rollno = str(rollno).strip()
        self.name = str(name).strip()
        self.marks = [float(mark) if mark not in (None, "") else None for mark in marks]

    def completed_marks(self):
        """Return only marks that are available."""
        return [mark for mark in self.marks if mark is not None]

    def total(self):
        return sum(self.completed_marks())

    def percentage(self):
        marks = self.completed_marks()
        if not marks:
            return 0.0
        return self.total() / len(marks)

    def grade(self):
        percentage = self.percentage()
        if percentage >= 90:
            return "A+"
        elif percentage >= 80:
            return "A"
        elif percentage >= 70:
            return "B"
        elif percentage >= 60:
            return "C"
        elif percentage >= 40:
            return "D"
        return "F"

    def display_details(self):
        return (
            f"Roll No: {self.rollno}\n"
            f"Name: {self.name}\n"
            f"Marks: {self.marks}\n"
            f"Total: {self.total():.2f}\n"
            f"Percentage: {self.percentage():.2f}%\n"
            f"Grade: {self.grade()}"
        )


class UndergraduateStudent(Student):
    """Example subclass demonstrating inheritance."""

    def display_details(self):
        return "Undergraduate Student\n" + super().display_details()


class PostgraduateStudent(Student):
    """Example subclass demonstrating polymorphism."""

    def display_details(self):
        return "Postgraduate Student\n" + super().display_details()
